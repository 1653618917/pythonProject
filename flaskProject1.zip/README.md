# Meeting


## Dependencies

1. Python3 (>=3.10)


## Usage

Run Script :

   ```shell
   python3 app.py
   ```
补充：
1.一些常用sql
sqlite3 meeting.db
.tables  #查看所有Table
SELECT * FROM user;
PRAGMA table_info(room);  #查看表中的所有字段

[//]: # (cid：列的整数ID（从0开始）。)

[//]: # (name：列的名称。)

[//]: # (type：列的数据类型。)

[//]: # (notnull：一个整数，表示该列是否不允许NULL值（1表示不允许，0表示允许）。)

[//]: # (dflt_value：列的默认值（如果有的话）。)

[//]: # (pk：一个整数，表示该列是否是主键的一部分（1表示是，0表示不是）。)






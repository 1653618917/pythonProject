from flask import Flask, request, redirect, url_for,render_template,session
import flask_login


app = Flask(__name__)
app.secret_key='ssssssss'

login_manager=flask_login.LoginManager()

login_manager.login_view='login'
login_manager.login_message_category='info'
login_manager.login_message='Access denied'
login_manager.init_app(app)

users={'foo@bar.tld':{'password':'secret'}}

class User(flask_login.UserMixin):
    pass

@login_manager.user_loader
def user_loader(email):
    if email not in users:
        return

    user=User()
    user.id=email
    return user

@login_manager.request_loader
def request_loader(request):
    email=request.form.get('email')
    if email not in users:
        return
    user=User()
    user.id=email
    return user


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return '''
               <form action='login' method='POST'>
                <input type='text' name='email' id='email' placeholder='email'/>
                <input type='password' name='password' id='password' placeholder='password'/>
                <input type='submit' name='submit'/>
               </form>
               '''

    email = request.form['email']
    if email in users and request.form['password'] == users[email]['password']:
        user = User()
        user.id = email
        flask_login.login_user(user)
        return redirect(url_for('protected'))

    return 'Bad login'


@app.route('/protected')
@flask_login.login_required
def protected():
    print(session)
    return 'Logged in as: ' + flask_login.current_user.id

@app.route('/logout')
def logout():
    flask_login.logout_user()
    return 'Logged out'

@login_manager.unauthorized_handler
def unauthorized_handler():
    return render_template("404.html")


@app.route('/')
@flask_login.login_required
def hello_world():  # put application's code here
    return redirect(url_for('login'))





if __name__ == '__main__':
    app.run()
